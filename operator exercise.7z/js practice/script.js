var a = prompt ("Please Enter Your Temprature: ");
var result = 9/5*a+32;
alert ("Ferenheit: "+ result + "Degree");
console.log ("Task Complete");